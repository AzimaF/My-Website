function penjumlahan(bil1, bil2) {
  // memberikan hasil penjumlahan
  return bil1 + bil2;
}
// menjalankan penjumlahan 12 + 10
const hasil = penjumlahan(12, 10);
console.log(hasil); // output: 22